package com.example.hambugi;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.Nullable;

public class EndDay extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_counter);
    }
}
